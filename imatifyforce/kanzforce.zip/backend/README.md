Backend (Node + Express) Starter

Commands:
- npm install
- npm start

Environment:
- Copy .env.example to .env and set values (Paddle keys, Firebase project id).

Security:
- This demo uses a simple admin upload endpoint. Protect it with authentication checks in production.
