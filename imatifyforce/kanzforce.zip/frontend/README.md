Frontend (React + Tailwind) Starter

Commands:
- npm install
- npm run dev

Environment:
- Copy .env.example to .env.local and set Firebase config values.

Notes:
- Tailwind is preconfigured.
